package com.example.uts_181011450487

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
